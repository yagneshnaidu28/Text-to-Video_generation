[![image](https://img.shields.io/discord/772774097734074388?label=Discord&logo=discord)](https://discord.com/servers/software-engineering-courses-secourses-772774097734074388) [![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FFurkanGozukara%2FStable-Diffusion%2Fedit%2Fmain%2FPatreon-Posts-Index.md&count_bg=%2379C83D&title_bg=%239E0F0F&icon=apachespark.svg&icon_color=%23E7E7E7&title=views&edge_flat=false)](https://hits.seeyoufarm.com) 

[![Patreon](https://img.shields.io/badge/Patreon-Support%20Me-F2EB0E?style=for-the-badge&logo=patreon)](https://www.patreon.com/SECourses) [![BuyMeACoffee](https://img.shields.io/badge/Buy%20Me%20a%20Coffee-ffdd00?style=for-the-badge&logo=buy-me-a-coffee&logoColor=black)](https://www.buymeacoffee.com/DrFurkan) [![Furkan Gözükara Medium](https://img.shields.io/badge/Medium-Follow%20Me-800080?style=for-the-badge&logo=medium&logoColor=white)](https://medium.com/@furkangozukara) [![Codio](https://img.shields.io/static/v1?style=for-the-badge&message=Articles&color=4574E0&logo=Codio&logoColor=FFFFFF&label=CivitAI)](https://civitai.com/user/SECourses/articles) [![Furkan Gözükara Medium](https://img.shields.io/badge/DeviantArt-Follow%20Me-990000?style=for-the-badge&logo=deviantart&logoColor=white)](https://www.deviantart.com/monstermmorpg)

[![YouTube Channel](https://img.shields.io/badge/YouTube-SECourses-C50C0C?style=for-the-badge&logo=youtube)](https://www.youtube.com/SECourses)  [![Furkan Gözükara LinkedIn](https://img.shields.io/badge/LinkedIn-Follow%20Me-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/furkangozukara/)   [![Udemy](https://img.shields.io/static/v1?style=for-the-badge&message=Stable%20Diffusion%20Course&color=A435F0&logo=Udemy&logoColor=FFFFFF&label=Udemy)](https://www.udemy.com/course/stable-diffusion-dreambooth-lora-zero-to-hero/?referralCode=E327407C9BDF0CEA8156) [![Twitter Follow Furkan Gözükara](https://img.shields.io/badge/Twitter-Follow%20Me-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white)](https://twitter.com/GozukaraFurkan)

# SECourses Patreon

YouTube : https://www.youtube.com/SECourses

Patreon : https://www.patreon.com/SECourses

Please join discord and message me there so I can give you Patreon rank in our channel

Discord : https://discord.com/servers/software-engineering-courses-secourses-772774097734074388

Your Patreon support is tremendously important for me so thank you so much

## Important Public Sharings

### Feburary 18 - 2024
[Full Workflow For Newbie Stable Diffusion Trainers For SD 1.5 Models & SDXL Models Training With DreamBooth & LoRA
](https://www.patreon.com/posts/full-workflow-sd-98620163)
* If you are new to Stable Diffusion and want to learn easily to train it with very best possible results, this article is prepared for this purpose with everything you need.

## Patreon Exclusive Content 

### June 6 - 2024
[Tencent AI Lab - V-Express Image to Animation Gradio Web APP and 1-Click Installers for Windows, Massed Compute, RunPod and Kaggle](https://www.patreon.com/posts/105251204)
* 1-Click to turn your static image into a full animation talking video either by an input audio or video file via Tencent AI Lab - V-Express - Open Source D-ID and alikes

### May 31 - 2024
[Most Advanced 1-Click DeepFake / FaceSwap App Rope Installer for Windows and Massed Compute and Linux](https://www.patreon.com/posts/most-advanced-1-105123768)
* The easiest and most powerful 1-click DeepFake / FaceSwap open source app Rope installers for Windows, Massed Compute, Linux and a lot of configurations and test results shared

### May 28 - 2024
[SUPIR 1 Click Windows, RunPod / Massed Compute / Linux Installer & Free Kaggle Notebook](https://www.patreon.com/posts/99176057)
* 1 Click Windows and RunPod / Massed Compute / Linux Installer and a free Kaggle Notebook For The New SOTA Image Upscaling and Enhancing Open Source SUPIR Model. Better than Magnify AI. SUPIR is the very best AI image upscaler at the moment.

### May 28 - 2024
[Hugging Face Upload / Download Notebook - Supports Private Repositories and Multi Commit as Well](https://www.patreon.com/posts/104672510)
* If you are looking for convenient and fast way to save and download your files from Hugging Face, this notebook will do the job. 1-click easy

### May 27 - 2024
[ComfyUI automatic Installers for Windows, RunPod, Massed Compute, Linux](https://www.patreon.com/posts/105023709)
* 1 Click auto installers for ComfyUI latest version for Windows, Massed Compute and RunPod. Installs latest version of ComfyUI into an isolated Python venv. Auto download best SDXL and SD 1.5 models and auto installs ComfyUI manager and Ip Adapter of ComfyUI. 

### May 27 - 2024
[IP-Adapter-FaceID-PlusV2 - 0 Shot Face Transfer - Auto Installer & Gradio App](https://www.patreon.com/posts/ip-adapter-0-app-95759342)
* 1 Click Auto Install IP-Adapter-FaceID-PlusV2. Use it with an advanced standalone Gradio app. 0 Shot face transfer and generate images. 

### May 27 - 2024
[Virtual Try-on (IDM-VTON) 1 Click Installers - Try Any Clothing Immediately On Anyone](https://www.patreon.com/posts/86438018)
* 1 Click installers (Windows, RunPod, Massed Compute, Linux, Kaggle Notebook) for IDM-VTON (Improving Diffusion Models for Authentic Virtual Try-on in the Wild). Click to install and start using

### May 25 - 2024
[Run Automatic1111 SD Web UI On A Free Kaggle NoteBook Like In Your PC - Supports SDXL & ControlNet](https://www.patreon.com/posts/run-on-free-like-88714330)
* A Free Kaggle account notebook to use Automatic1111 for free. Supports SDXL, ControlNet, LoRA, trained LoRAs & automatic extension install. Works like you have a very strong computer. Dual 15 GB GPUs, 29 GB RAM provided for free by Kaggle. Auto downloads all of the ControlNet models for both SD 1.5 and SDXL models including even IP Adapter Face ID Plus and InstantID

### May 21 - 2024
[The Very Best Workflow For SDXL DreamBooth / Full Fine Tuning - Results Of 100+ Full Trainings](https://www.patreon.com/posts/very-best-for-of-89213064)
* Updated the very best hyper training parameters / configuration and training workflow for Kohya SS GUI for Stable Diffusion XL (SDXL)

### May 20 - 2024
[Massed Compute Installers - Upgrade Automatic1111 - Coupon Code - ControlNet - ADetailer - Facefusion - Reactor & More](https://www.patreon.com/posts/101386817)
* Massed Compute Scripts & Coupon Code: A6000 GPU for 31 Cents Per Hour, Automatic1111 SD Web UI, Kohya, OneTrainer, After Detailer (ADetailer), Reactor, Facefusion, Forge & More

### May 20 - 2024
[1 Click Installer for Automatic1111 SD Web UI, SDXL, ControlNet, All ControlNet Models, TensorRT (RTX Accelerator) on Windows](https://www.patreon.com/posts/86307255)
* Automatic Windows installer script for SDXL and Automatic1111 Web UI. Downloads latest SDXL base with fixed VAE and best SD 1.5 and SDXL models. Moreover it automatically installs and lets you download newest NVIDIA RTX Accelerator - TensorRT which brings 70%+ Speed Up. Moreover, it will automatically install ControlNet and download all available ControlNet models for you. Furthermore, it will auto install After Detailer (ADetailer) and Reactor extensions and latest Torch and xFormers. All these installations are optional and you can install any of them.

### May 19 - 2024
[1 Click Installer for Automatic1111 SD Web UI, SDXL, ControlNet, All ControlNet Models, TensorRT (RTX Accelerator) For RunPod / Any Linux System](https://www.patreon.com/posts/86438018)
* Automatic RunPod (any Linux System) installer script for SDXL and Automatic1111 Web UI. Downloads latest SDXL base with fixed VAE and best SD 1.5 and SDXL models. Moreover it automatically installs and lets you download newest NVIDIA RTX Accelerator - TensorRT which brings 70%+ Speed Up. Moreover, it will automatically install ControlNet and download all available ControlNet models for you. Furthermore, it will auto install After Detailer (ADetailer) and Reactor extensions and latest Torch and xFormers. All these installations are optional and you can install any of them.

### May 16 - 2024
[Stable Cascade 1 Click Installer & Advanced Gradio APP For Windows, Massed Compute, RunPod, Linux & Kaggle](https://www.patreon.com/posts/stable-cascade-1-98410661)
* 1 Click To Install Stable Cascade Model & Use On Your PC or On RunPod or On Massed Compute or Kaggle With Amazing Optimizations (Works on 5GB GPU) & Advanced GUI

### May 7 - 2024
[FaceFusion (Most Advanced 1-Click DeepFake) 1-Click Installer for Windows, RunPod, Massed Compute & Kaggle Notebook](https://www.patreon.com/posts/103765029)
* FaceFusion (Most Advanced 1-Click DeepFake) APP 1-Click Installer for Windows, RunPod, Massed Compute & free Kaggle account Notebook

### April 28 - 2024
[Fooocus SD Web UI RunPod & Massed Compute Auto Installer - 1 Click - Latest Version](https://www.patreon.com/posts/fooocus-sd-web-1-92759045)
* Automatic installer for Stable Diffusion Fooocus Web UI on RunPod and also Massed Compute. 1 Click. Use Fooocus on RunPod & Massed Compute with all models and features. Latest version. Follow the instructions on the Patreon post.

### April 18 - 2024
[Kohya SD 1.5 & SDXL LoRA - DreamBooth Training Free Kaggle NoteBook](https://www.patreon.com/posts/kohya-sdxl-lora-88397937)
* A Kaggle NoteBook file to do Stable Diffusion 1.5 & XL (SDXL) Kohya GUI both LoRA and DreamBooth training on a free Kaggle account. If you don't have a strong GPU this is the notebook you need. It supports even SDXL DreamBooth full fine tuning.

### April 18 - 2024
[For RunPod - Automatic Kohya SS LoRA Installer](https://www.patreon.com/posts/for-runpod-kohya-84898806)
* This script will automatically install Kohya SS on RunPod. Additionally, I have added after Pod restart script which will fix installation.

### March 31 - 2024
[Auto Installer Script For Roop (DeepFake) On RunPod & Example Image And Videos](https://www.patreon.com/posts/auto-installer-84511510)
* How to automatically install DeepFake Roop with 1 click on RunPod and use it. Step by step instructions and 1click installer script file

### March 30 - 2024
[OneTrainer Stable Diffusion XL (SDXL) Fine Tuning Best Presets](https://www.patreon.com/posts/96028218)
* Nerogar OneTrainer very best Stable Diffusion XL (SDXL) full fine tuning presets. 14 GB GPU is very sufficient and fast

### March 22 - 2024
[The Very Best OneTrainer Workflow & Config For SD 1.5 Based Models DreamBooth / Full Fine Tuning](https://www.patreon.com/posts/very-best-config-97381002)
* Download the very best training configuration and learn the workflow for the OneTraine GUI Stable Diffusion trainer & obtain amazing quality. The workflow is discovered after 70 empricial model trainings.

### March 20 - 2024
[Auto RunPod Installer For SDXL Background Replacement for Product Images - Make Amazing Product Ads For Shopify](https://www.patreon.com/posts/auto-runpod-for-89919157)
* 1 Click Install Shopify Product Background Replacer (Open Source) And Make Amazing Ads Pictures For Your Products On RunPod With SDXL

### March 20 - 2024
[Auto Windows Installer & Free Kaggle Notebook For SDXL Background Replacement for Product Images - Make Amazing Product Ads For Shopify](https://www.patreon.com/posts/auto-windows-for-89914747)
* 1 Click Install Shopify Product Background Replacer (Open Source) And Make Amazing Ads Pictures For Your Products On Your Computer With SDXL and also Kaggle Notebook to use it on Kaggle for free

### March 20 - 2024
[Bit-By-Bit Disk & File Verification Software In C#, Fully Multi-Threaded, With Full Source Code - Verify Disk Clone](https://www.patreon.com/posts/76398813)
* This in C# developed application is extremely efficient to verify every bit of cloned disks. It can be also used for file migration/backup verification. Full source code available with pre-compiled exe file. It is fully multi-threaded. 

### March 18 - 2024
[1 Click Automatic Installer & A Very Advanced GUI For InstantId For Windows, RunPod, Linux & Kaggle Notebook](https://www.patreon.com/posts/1-click-very-gui-97769887)
* Advanced Gradio Web UI & Automatic Installers For Windows, RunPod, Kaggle & Linux For InstantID: Zero-shot Identity-Preserving Generation in Seconds

### March 12 - 2024
[Fooocus Stable Diffusion Web UI Kaggle NoteBook](https://www.patreon.com/posts/fooocus-stable-94269866)
* Fooocus Stable Diffusion Web UI Free Kaggle Account Notebook. Use SDXL on Kaggle for free like Midjourney without even a computer. This is the way to use almost Midjourney for free.

### Feburary 16 - 2024
[1 Click Auto Roop (DeepFake - FaceSwap) Local Windows Installer Script](https://www.patreon.com/posts/1-click-auto-88234834)
* Automatic Roop DeepFake / FaceSwap installer script. 1 click to install and 1 click to run and start using it very easily.

### Feburary 15 - 2024
[1 Click Auto Windows Installer For Rerender A Video - 1 Click Video To Anime](https://www.patreon.com/posts/89457537)
* Rerender is an amazing new Paper that allows you to turn videos into Anime with 1 click. Auto install scripts and instructions provided here

### Feburary 12 - 2024
[SOTA Image Captioning Scripts For Stable Diffusion: CogVLM, LLaVA, BLIP-2, Clip-Interrogator (115 Clip Vision Models + 5 Caption Models)](https://www.patreon.com/posts/sota-image-for-2-90744385)
* State Of The Art - The Very Best > Image Captioning Scripts For Stable Diffusion: Kosmos-2, CogVLM, LLaVA, BLIP-2, Clip-Interrogator (115 Clip Vision Models + 5 Caption Models)

### Feburary 10 - 2024
[Sort AI Generated Images By Their Similarity With DeepFace & RetinaFace](https://www.patreon.com/posts/sort-ai-images-82478694)
* With DeepFace & RetinaFace libraries we will sort AI generated images with best accuracy to your original. Thus, you can find best ones easy

### Feburary 5 - 2024
[1 Click Auto RunPod Installer For Rerender A Video - 1 Click Video To Anime](https://www.patreon.com/posts/1-click-auto-for-91039997)
* Rerender is an amazing new AI that allows you to turn videos into Anime with 1 click. RunPod auto install scripts and instructions are here.

### January 29 - 2024
[The Very Best Kohya GUI Workflow & Config For SD 1.5 Based Models DreamBooth / Full Fine Tuning](https://www.patreon.com/posts/very-best-kohya-97379147)
* Download the very best training configuration and learn the workflow for the Kohya SS GUI Stable Diffusion trainer & obtain amazing quality. The workflow is discovered after 70 empricial model trainings. 

### January 23 - 2024
[Download 160 Very Best Stable Diffusion 1.5 Based (SD 1.5) Models With 1 Click](https://www.patreon.com/posts/96666744)
* 1 click Download the very best 160+ Stable Diffusion 1.5 models (SD 1.5) from CivitAI and Hugging Face into your PC or RunPod or Cloud.

### January 16 - 2024
[PixArt-alpha (PixArt-α) Automatic Installer For Both Windows And RunPod With Additional Web UI Features](https://www.patreon.com/posts/pixart-alpha-for-93614549)
* Auto installer scripts with an Advanced Web Gradio APP to install and use PIXART-α (PixArt-alpha - SDXL Rival) for both Windows and RunPod. 

### January 14 - 2024
[Tortoise TTS Fast (tortoise-tts-fast) Windows Auto Installer BAT Script](https://www.patreon.com/posts/tortoise-tts-tts-90496485)
* 1 Click installer for tortoise-tts-fast on Windows. It will make its own VENV so will not affect any other AI apps such as Stable Diffusion.

### January 1 - 2024
[Magic Animate Automatic Installer and Video to DensePose Auto Converter For Windows And RunPod](https://www.patreon.com/posts/94098751)
* Automatically install magic-animate on both Windows and RunPod. Also automatically generate DensePose from raw videos via best detectron2. Includes a standalone CodeFormer Gradio Web APP too for improving faces in videos fully automatically.

### December 23 - 2023
[Batch Image Metadata Generator - Extremely Useful For Automatic1111 SD Web UI](https://www.patreon.com/posts/95176238)
* If you want to batch generate Metadata of images with just one click, this is the script you are looking for. Extremely useful for SD Web UI

### December 23 - 2023
[Find And Move Duplicate or Very Similar Images By Using imagehash - Batch Processing Super Fast](https://www.patreon.com/posts/find-and-move-or-95143007)
* If you want to find duplicate or near duplicate images very fast, this script is what you are looking for. It analyzes the content of images so works amazingly

### December 23 - 2023
[All Amazing Styles Of Fooocus As Automatic1111 SD Web UI Styles File And Styles File Generator](https://www.patreon.com/posts/all-amazing-of-95143823)
* 275 Amazing Fooocus Styles in a single Styles.csv file compatible with Automatic1111 and Styles.csv generator for Fooocus styles folder.

### December 4 - 2023
[Auto Installer For AudioCraft Plus - MusicGen - AudioGen - An All-in-One AudioCraft WebUI](https://www.patreon.com/posts/ai-music-auto-84334460)
* Auto Installer Windows Bat Files For AudioCraft Plus - MusicGen - AudioGen - An All-in-One AudioCraft WebUI - Facebook Research / Audiocraft

### November 27 - 2023
[Massive 4K Resolution Woman & Man Class Ground Truth Stable Diffusion Regularization Images Dataset](https://www.patreon.com/posts/massive-4k-woman-87700469)
* 4K+ resolution 5200 images for each gender Hand Picked Ground Truth Real Man & Woman Regularization Images For Stable Diffusion & SDXL Training - 512px 768px 1024px 1280px 1536px and more

### November 25 - 2023
[SOTA Subject Cropper and Face Focused Image Resizer Scripts Do Better Training](https://www.patreon.com/posts/sota-subject-and-88391247)
* State Of The Art (SOTA) Subject Cropper (Zoom Subject Without Quality Loss) and SOTA Image Downscaler To Get Perfect Desired Resolution. These scripts will significantly improve your training quality.

### November 25 - 2023
[SOTA (The Very Best) Image Captioning Models Script For Stable Diffusion And More](https://www.patreon.com/posts/sota-very-best-90744385)
* 1 Click install and use SOTA image captioning models on your computer. Supports 8 bit loading as well. 90+ CLIP Vision and 5+ Caption models. Supports  laion/CLIP-ViT-bigG-14-laion2B-39B-b160k too. Supports total 115 Clip and 5 Caption model combination. 

### November 20 - 2023
[Image Validator Script For Training - Moves Corrupted Images](https://www.patreon.com/posts/image-validator-85618765)
* This attached below script will test each one of your images and moves the ones that are corrupted (breaking training) into another folder. Another script will scan and log but not move.

### November 17 - 2023
[Automatic ControlNet Installer And Downloader For Windows BAT File](https://www.patreon.com/posts/84875387)
* Scripts will clone ControlNet repo and download all of the ControlNet models with SDXL into the correct folder automatically for Windows

### November 12 - 2023
[Gender Classifier - Low Colors & Multiple Face Remover - Stable Diffusion Training Images Preprocessor](https://www.patreon.com/posts/92607385)
* Gender Classifier - Low Colors & Multiple Face Remover - Stable Diffusion Training Images Preprocessor. Utilizes SOTA models and techniques. Supports GPU Retina Face too.

### November 9 - 2023
[Automatic ControlNet Installer / Updater - Model Downloader For RunPod](https://www.patreon.com/posts/84896373)
* This script will update ControlNet extension to its latest version and also automatically download all model files of ControlNet

### November 6 - 2023
[Auto Installer Bat Files For Automatic1111 & DreamBooth Extension On Windows](https://www.patreon.com/posts/auto-installer-84773926)
* Included BAT script files will clone and install fully automatically Automatic1111 SD Web UI and DreamBooth extension for you on Windows.

### October 28 - 2023
[RunPod Auto DreamBooth Extension Of Automatic1111 Web UI & Latest Libraries Installer Script](https://www.patreon.com/posts/runpod-auto-84716845)
* This script will install working version of DreamBooth extension of Automatic1111 Web UI fully automatically for you on RunPod. 

### October 24 - 2023
[Automatic1111 Web UI Google Colab NoteBook With All ControlNet Models And More](https://www.patreon.com/posts/automatic1111-ui-89288738)
* Automatic1111 Web UI Google Colab Notebook With All ControlNet Models, SDXL Model, Best SD 1.5 Model, LoRA Download Example, Upscaler, SDXL LoRAs, SDXL ControlNet All Models & More

### October 5 - 2023
[Amazing Prompt List For DreamBooth or LoRA Trained Stable Diffusion XL (SDXL) & SD 1.5 Based Models](https://www.patreon.com/posts/amazing-prompt-1-90346033)
* Specially crafted very best Stable Diffusion XL (SDXL) + SD 1.5 based models prompt list for DreamBooth and LoRA trained models.

### September 14 - 2023
[Google Colab Notebook For Würstchen: Fast Diffusion for Image Generation](https://www.patreon.com/posts/google-colab-for-89280042)
* Würstchen V2 model on a free Google Colab Notebook with instructions. Super quality Generative AI like Stable Diffusion XL (SDXL) but faster

### September 14 - 2023
[Auto Windows Installer For Würstchen: Fast Diffusion for Image Generation](https://www.patreon.com/posts/auto-windows-for-89265135)
* Install latest Generative AI model Würstchen V2 to your computer with 1 click. Fixed file instead of broken Gradio demo hosted on Hugging Face

### September 12 - 2023
[How To Start Multiple Automatic1111 Web UI And Kohya Training On A Single Pod](https://www.patreon.com/posts/how-to-start-web-89150521)
* Download webui-user.sh and relauncher.py files and follow instructions to start multiple Automatic1111 on different GPUs on a  single RunPod

### August 13 - 2023
[Convert Very Long X/Y/Z Plot Output Images Into Square Grids](https://www.patreon.com/posts/convert-very-x-y-87608128)
* A script to convert very long X/Y/Z Plot image into a chunked Square Grid Image. Examples are attached.

### August 8 - 2023
[1 Click RunPodCTL Installer .bat File - Script](https://www.patreon.com/posts/1-click-bat-file-87505171)
* 1 Click installer for runpodctl. runpodctl is super fast to upload and download files between pod to pc, pc to pod and pod to pod.

### August 1 - 2023
[How To Get Amazing Prompts With ChatGPT For Stable Diffusion](https://www.patreon.com/posts/how-to-get-with-87038686)
* How to Utilize free ChatGPT to write unlimited number of different prompts for Stable Diffusion models. 540 prompts attached

### July 29 - 2023
[SDXL Kohya LoRA Training With 12 GB VRAM Having GPUs - Tested On RTX 3060](https://www.patreon.com/posts/sdxl-kohya-lora-86817035)
* How to do SDXL Kohya LoRA training with 12 GB VRAM having GPUs. Rank 8, 16, 32, 64, 96 VRAM usages are tested and shown. Config provided

### July 27 - 2023
[How To Fix Artifacts In The SDXL 1.0 VAE - Hidden Watermark System](https://www.patreon.com/posts/86736816)
* How to get rid off embedded watermarking system in SDXL 1.0 VAE. We will use new VAE. How to use proper VAE with SDXL for best quality.

### July 12 - 2023
[1k Resolution Class Images & Direct SDXL Download Links](https://www.patreon.com/posts/1k-resolution-85976249)
* 1024x1024 Pixels Class Images (From Real Pictures) For Amazing Realism For SDXL and Direct SDXL 0.9 and 1.0 Download Links (Official Source)

### July 10 - 2023
[Auto SDXL RunPod Installer Script - 1 Click ](https://www.patreon.com/posts/auto-sdxl-runpod-85845581)
* 1 Click SDXL Installer Script for RunPod. Working amazing. Use high VRAM GPUs for amazing speed. You don't need token I did set it for you.

### July 6 - 2023
[Auto Installer Script (.bat) Files For Stable Diffusion XL (SDXL) On Your PC](https://www.patreon.com/posts/auto-installer-85678961)
* Attached script files will automatically download and install SD-XL 0.9 into your computer and let you use SDXL locally for free as you wish

### July 4 - 2023
[Best Settings For The END of Photography - Use AI to Make Your Own Studio Photos, FREE Via DreamBooth Training](https://www.patreon.com/posts/best-settings-of-85192985)
* Screenshots of best settings for : The END of Photography - Use AI to Make Your Own Studio Photos, FREE Via DreamBooth Training

### June 21 - 2023
[How to fix Roop (insightface error) - cannot open include file: 'stdio.h': No such file or directory](https://www.patreon.com/posts/how-to-fix-roop-84932008)
* This post will show you how to fix insightface wheel compiling error when installing Roop on Windows. 'stdio.h': No such file or directory

### June 20 - 2023
[Auto Installer Bat File For Latest cuDNN dll files & How To Manually Install & Update](https://www.patreon.com/posts/auto-installer-84830198)
* Attached bat file will automatically download 8.9.2.26 cuDNN dll files and replace the ones that comes with default Torch installation 

### June 16 - 2023
[Core i7 10700F vs Core i9 13900K](https://www.patreon.com/posts/core-i7-10700f-84640971)
* Core i7 10700F vs Core i9 13900K results are shown in the image. Alternatively you can watch the youtube video to see them.

### June 9 - 2023
[2 Pre-Processing Scripts And 3 Datasets Of Processed Class Images For Popular Models](https://www.patreon.com/posts/84292083)
* Video Tutorial for this post : https://youtu.be/olX1mySE8HA. Batch preprocess images. Removes multiple-face, black & white, NSWF. Free datasets 

### June 6 - 2023
[Mind-Blowing Deepfake Tutorial: Turn Anyone into Your Favorite Movie Star! PC & Google Colab - roop](https://www.patreon.com/posts/mind-blowing-pc-84169579)
* Full video of: Mind-Blowing Deepfake Tutorial: Turn Anyone into Your Favorite Movie Star! PC & Google Colab - roop

### June 4 - 2023
[4K 2700 Real Class Images + Auto Cropping Script](https://www.patreon.com/posts/4k-2700-real-84053021)
* 4K res 2700 Class / Reg raw images. Subject auto cropper script. Included 512, 640, 768, 960, 1024px prepared. Can be used for fine-tuning

### May 30 - 2023
[1 Click DeepFake Tutorial](https://www.patreon.com/posts/1-click-deepfake-83785289)
* DeepFake Roop example video and face images attached. The links are in the post.

### May 28 - 2023
[How To Generate Very Long Text To Speech For Free On Cloud, e.g. Audiobook](https://www.patreon.com/posts/how-to-generate-83649203)
* Generate a very long text to speech with a single click on cloud for free. Example Audiobook  : https://www.youtube.com/watch?v=5dSiuBjVcdk

### May 8 - 2023
[Voice Clone Tutorial Scripts](https://www.patreon.com/posts/voice-clone-82712205)
* As shown in the tutorial video, the scripts I have developed make voice cloning and text-to-speech synthesis much easier and more efficient.

### April 30 - 2023
[Enhanced DeepFloyd-IF Kaggle Notebook File](https://www.patreon.com/posts/enhanced-if-file-82253574)
* Enhanced DeepFloyd-IF Kaggle Notebook File as shown in the tutorial video.

### April 26 - 2023
[Realistic Vision V2 - 2071 classification / regularization images](https://www.patreon.com/posts/realistic-vision-82085317)
* Realistic Vision V2 - 2071 classification / regularization images

### April 26 - 2023
[Kohya SS LoRA Amazing Studio Quality Photoshoot Tutorial PDF](https://www.patreon.com/posts/kohya-ss-lora-82085260)
* The attached PDF file will be updated once the tutorial is finished and published.

### April 18 - 2023
[Kandinsky 2.1 For FREE Google Colab Account - Save in Drive, Batch Processing, Dynamic Prompting](https://www.patreon.com/posts/82085260)
* Kohya SS Tutorial as PDF file

### April 11 - 2023
[Summary And Conclusions of RTX 3090 vs RTX 3060 Ultimate Showdown for Stable Diffusion, ML, AI & Video Rendering Performance](https://www.patreon.com/posts/summary-and-of-81374648)
* You can download the summary, discoveries and the conclusions PDF file of the video : https://youtu.be/lgP1LNnaUaQ RTX 3090 vs RTX 3060 Ulti 

### April 6 - 2023
[Kandinsky 2 Tutorial And Script](https://www.patreon.com/posts/kandinsky-2-and-81107231)
* The tutorial link is here : https://youtu.be/dYt9xJ7dnpU My modified improved notebook file is attached. I may update it time to time. This 

### April 6 - 2023
[Custom Style Teached New Model](https://www.patreon.com/posts/custom-style-new-81107154)
* This is a custom model that I have trained a certain style as you see in the picture. You can use it as you wish.

### April 2 - 2023
[How To Quickly Upload Your RunPod Files To Google Drive](https://www.patreon.com/posts/how-to-quickly-80924234)
* By using the following Google Colab Notebook link you can very quickly upload your files (e.g. models or folders) to your Google Drive.

### March 27 - 2023
[10598 Aesthetic and 6080 Photo Of Man classification images](https://www.patreon.com/posts/10598-aesthetic-80588052)
* You can download from below links 10598 aesthetic and 6080 photo of classification images. You can use these images as regularization / clas

### March 22 - 2023
[Midjourney Level Style Trained Model](https://www.patreon.com/posts/midjourney-level-80356527)
* This is the video tutorial : https://youtu.be/m-UVVY_syP0 . Safetensors model file below. This model do not include myself - only style 

### March 19 - 2023
[Style Teaching & Aesthetic Dataset](https://www.patreon.com/posts/style-teaching-80233878)
* 2858 Style training images dataset prepared by me with the following words and certain prompt usage : https://drive.google.com/file/d/1A

### January 28 - 2023
[How To Achieve Synchronization In C# While Doing Async Await Multithreaded Programming - .NET Core](https://www.patreon.com/posts/how-to-achieve-c-77858916)
* Thank you so much for supporting us. Source code available in attachments. 

### xformers need to be updated posts time to time
* https://github.com/FurkanGozukara/stable-diffusion-xl-demo
